﻿using Microsoft.EntityFrameworkCore;

namespace EmployeeRegistration.Models
{
    public class EmployeeDetalsContext:DbContext

    {
        public EmployeeDetalsContext(DbContextOptions<EmployeeDetalsContext> options): base (options)

        {




        }
        
        public DbSet<EmployeeDetail> EmployeeDetail { get; set; }  
    }
}
