﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace EmployeeRegistration.Models
{
    public class EmployeeDetail
    {
        [Key]
        public int ID { get; set; }

        [Column (TypeName = "nvarchar(100)")]
        public string FirstName { get; set; }

        [Column(TypeName = "nvarchar(100)")]
        public string LastName { get; set; }

        [Column(TypeName = "nvarchar(10)")]
        public int PhoNo { get; set; }

        [Column(TypeName = "nvarchar(50)")]

        public string EmailId { get; set; }


        [Column(TypeName = "nvarchar(100)")]
        public int DOb { get; set; }

        [Column(TypeName = "nvarchar(100)")]

        public int Salary { get; set; }

        [Column(TypeName = "nvarchar(100)")]

        public string State { get; set; }

        [Column(TypeName = "nvarchar(100)")]
        public string City { get; set; }

    }
}
